**Nested Association Mapping (NAM) Reveals Genetic Architecture of Agronomic Traits in Quinoa**

Flavio Lozano-Isla^1,2\*^; Milagros Ninoska Munoz-Salas^3^, Mireia Vidal-Villarejo^1^; Bettina I.G. Haussmann^1,4^; Angel Mujica Sanchez^5^; Karl Schmid^1\*^

^1^ Institute of Plant Breeding, Seed Science and Population Genetics, University of Hohenheim, Stuttgart, Germany

^2^ Present affiliation: Instituto de Investigación para el Desarrollo Sustentable de Ceja de Selva (INDES-CES), Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas, Chachapoyas, Peru.

^3^ Department of Earth and Environment, Institute of Environment, Florida International University, Miami, FL 33199, USA

^4^ Present affiliation: German Institute for Tropical and Subtropical Agriculture (DITSL GmbH), Witzenhausen, Germany

^5^ Programa de Mejoramiento Genético de Cultivos Andinos, Facultad de Ciencias Agrarias, Universidad Nacional del Altiplano, Puno, Peru

\*Corresponding author. 

Flavio Lozano -Isla <[flavio.lozano@untrm.edu.pe](mailto:flavio.lozano@untrm.edu.pe)> 

Karl Schmid <[karl.schmid@uni-hohenheim.de](mailto:karl.schmid@uni-hohenheim.de)>



ORCID IDs:


| **Author**                         | **ORCID**                          | **email**                           |
|------------------------------------|------------------------------------|-------------------------------------|
| **Flavio Lozano-Isla**             | 0000-0002-0714-669X                | flavio.lozano@untrm.edu.pe          |
| **Milagros Ninoska Munoz-Salas**   | 0009-0001-7278-5690                | mmuno126@fiu.edu                    |
| **Mireia Vidal-Villarejo**         | 0000-0002-7507-0930                | mireia.vidal@uni-hohenheim.de       |
| **Bettina I.G. Haussmann**         | 0000-0002-2360-6799                | bettina.haussmann@uni-hohenheim.de  |
| **Angel Mujica Sanchez**           | 0000-0002-7013-8780                | amujica@unap.edu.pe                 |
| **Karl Schmid**                    | 0000-0001-5129-895X                | karl.schmid@uni-hohenheim.de        |




**DECLARATIONS**

**Funding**

This study was supported by a capacity development grant from KWS SAAT SE & Co. KGaA awarded to the Universidad Nacional del Altiplano, Puno, and the University of Hohenheim.

**Data and code availability** 

All datasets and reproducible analysis scripts are provided in Supplementary File 1. The complete dataset and code are publicly available at the GitHub repository: [https://github.com/Flavjack/quinoa-genetics](https://github.com/Flavjack/quinoa-genetics)

**Author contributions**

BIGH and KS conceived the study. FLI and AMS performed material preparation, data collection and investigation. FLI and MVV curated the data. Methodology was developed by FLI, MNMS and MVV, and formal analysis was performed by FLI. Software was implemented by FLI and MVV. Visualization was prepared by FLI and MNMS. BIGH and KS acquired funding, and AMS provided project administration and resources. BIGH and KS supervised the study. FLI and MNMS wrote the first draft, and all authors contributed to review and editing. All authors read and approved the final manuscript.

**Acknowledgments**

The authors thank the Andean Crops Genebank of the Universidad Nacional del Altiplano (UNAP), Puno, Peru, for supplying the genetic materials used in this research.

**Competing interests**

The authors declare no competing financial or non-financial interests.

# ABSTRACT

Quinoa (*Chenopodium quinoa* Willd.) is a stress-tolerant pseudocereal recognized for its nutritional value and adaptation to marginal environments. However, breeding progress for yield and resilient cultivars remains constrained by limited knowledge of the genetic architecture of agronomic traits. To address this gap, two nested association mapping (NAM) populations were developed using the recurrent parents Salcedo INIA, a high-yielding cultivar, and Kancolla, a traditional highland landrace, crossed with four diverse founder cultivars from the Peruvian Altiplano. A total of 125 recombinant inbred lines were evaluated under multi-environment field trials in the Peruvian highlands for phenology, plant architecture, and grain yield traits. Low-coverage whole-genome resequencing produced 6,046 high-quality SNP markers. Population structure analyses showed differentiation between Salcedo- and Kancolla-derived families. Genome-wide association analysis identified 26 significant SNPs associated with eight agronomic traits, including flowering time, maturity, plant height, panicle morphology, and grain yield. Most loci were detected in the Kancolla-derived NAM population, highlighting the contribution of landrace germplasm to adaptive trait variation. Genomic prediction using GBLUP achieved predictive abilities up to 0.80 for phenology and planicle length. This study establishes the first NAM resource for quinoa and provides genomic insights to support cultivar development adapted to the Andean highlands.

**Keywords:** Andean crops; genetic diversity; genomic prediction; GWAS; plant breeding

```Unknown element type at this position: UNSUPPORTED```# INTRODUCTION

Quinoa (Chenopodium quinoa Willd.) is increasingly recognized as a nutritionally rich and stress-tolerant pseudocereal [[1,2]](https://www.zotero.org/google-docs/?Uf9WCb). Its grains contain a balanced profile of essential amino acids, polyunsaturated fatty acids, dietary fiber, vitamins, and minerals. They are also gluten-free and have a low glycaemic index, which are attributes that make them suitable for functional foods and specialized diets [[3]](https://www.zotero.org/google-docs/?tqmC6z). In addition to these nutritional properties, quinoa exhibits tolerance to multiple abiotic stresses, including drought, salinity, frost, and low-fertility soils, that enables cultivation in environments where traditional crops are less productive [[4–8]](https://www.zotero.org/google-docs/?F4l4Sj). This combination of resilience and nutritional quality positions quinoa as a strategic crop under a climate change scenario and for food security.

Global expansion of quinoa cultivation has accelerated since the International Year of Quinoa in 2013, with experimental and commercial cultivation now reported in more than 120 countries [[9]](https://www.zotero.org/google-docs/?SsZ7j9). Although Peru and Bolivia remain the principal producers and exporters, significant expansion has occurred in North America, Europe, Africa, and Asia [[9,10]](https://www.zotero.org/google-docs/?jl10T0). This globalization generates opportunities for diversification of food systems but also introduces challenges related to unstable yields, market fluctuations, and increasing pressure on the use of genetic resources [[10,11]](https://www.zotero.org/google-docs/?og3n8x). The conservation and targeted use of this genetic diversity are essential for developing new cultivars with greater yield stability and climate resilience.

Recent advances in genomics have shown the potential of improving quinoa cultivars by breeding for traits like resistance against downy mildew [[12,13]](https://www.zotero.org/google-docs/?c03mFB), early maturity and higher productivity [[14]](https://www.zotero.org/google-docs/?zWi7QV),  and  resilience against abiotic stresses  [[15,16]](https://www.zotero.org/google-docs/?h9GLuC). In addition, high-throughput phenotyping pipelines enable the systematic capture of the extensive phenotypic variation present among quinoa genetic resources [[17]](https://www.zotero.org/google-docs/?Km9Y33). Building on these advances, efforts toward QTL mapping, such as those by Maldonado-Taipe et al. [[14]](https://www.zotero.org/google-docs/?hmks49), have provided a foundation for integrating the diversity of genetic resources into breeding programmes. Genome-wide association study (GWAS) and bulk segregant analysis (BSA) approaches have identified genomic regions linked to downy mildew resistance and candidate defense-related genes, including a major resistance locus on chromosome 4 [[13,18]](https://www.zotero.org/google-docs/?M9hZMD). Similarly, the construction of the first genetic linkage maps has provided a basic framework for trait mapping but lacks the power to capture the allelic diversity present in quinoa germplasm [[19]](https://www.zotero.org/google-docs/?rqEseN). In contrast, nested association mapping (NAM), a multi-parent population design in which a common parent is crossed with multiple diverse founders, combines the high mapping resolution of genome-wide association studies with the power of linkage analysis [[20]](https://www.zotero.org/google-docs/?kjX7DD). This approach has proven effective in other crops [[21–23]](https://www.zotero.org/google-docs/?WPtox6) enabling precise dissection of quantitative traits and facilitating marker deployment in breeding by integrating the statistical resolution of linkage mapping with the allelic diversity of multi-parent populations.

This study explores the potential of NAM populations for dissecting complex agronomic and adaptive traits in quinoa. The integration of widely used cultivars in the Peruvian highlands, such as Salcedo INIA and traditional landraces such as Kancolla provides a foundation for including causal genetic variation for these traits in a NAM population design. We focus on the genetic analysis of NAM populations developed from crosses between Salcedo INIA, Kancolla, and diverse founder lines. Our objectives were (i) to assess the genetic structure and diversity of the NAM families, (ii) to identify QTLs for yield-related traits through joint linkage–association analyses, based on phenotyping data from two field trials in the Peruvian highlands, and (iii) to evaluate the predictive performance of genomic selection models. These populations represent a foundational genomic resource for quinoa improvement, providing a pathway to integrate genetic diversity into breeding pipelines for quinoa.

# MATERIALS AND METHODS

## Plant material and population development

In a previous study on quinoa breeding [[24]](https://www.zotero.org/google-docs/?LembFb), we developed six segregating populations derived from biparental crosses of traditional Peruvian cultivars to establish two nested association mapping (NAM) populations. A structured multi-parental design was implemented using two contrasting recurrent parents: Salcedo INIA (SAL) and Kancolla (KAN). The SAL-based panel was generated by crossing Salcedo INIA with three founder lines—Huariponcho (SAL × HUA), Pandela Rosada (SAL × PAN), and Negra Collana (SAL × NCO)—while the KAN-based panel comprised crosses between Kancolla and Huariponcho (HUA × KAN), Pasankalla (PAS × KAN), and Negra Collana (NCO × KAN). The F₁ progenies were advanced through five generations of selfing using a bulk method to increase homozygosity, producing 96 recombinant inbred lines (RILs) per cross. From these, 25 lines per population were selected and subsequently evaluated from the F₇ to F₉ generations in multi-location field trials across the Peruvian highlands to assess agronomic performance, yield stability, and adaptation under contrasting environmental conditions.

![Breeding scheme for nested association mapping (NAM) using two populations developed for a quinoa breeding program in the Peruvian highlands. Two recurrent parents were used: Salcedo INIA (SAL) and Kancolla (KAN). SAL was crossed with Huariponcho (SALxHUA), Pandela Rosada (SALxPAN), and Negra Collana (SALxNCO), while KAN was crossed with Huariponcho (HUAxKAN), Pasankalla (PASxKAN), and Negra Collana (NCOxKAN).](img_0.jpg){#fig:id.ov1ed4akrh9f}

Parental lines were selected based on agronomic performance, phenotypic divergence, and adaptation to Andean highland environments [[24]](https://www.zotero.org/google-docs/?C9EFaF). Salcedo INIA is a widely used cultivar characterized by high yield potential and resistance to frost and powdery mildew [[25]](https://www.zotero.org/google-docs/?amysAK), and has also been studied for its postharvest physical properties and grain quality at different altitudes [[26]](https://www.zotero.org/google-docs/?PznQYG). In contrast, Kancolla is a traditional landrace noted for its cold and hail tolerance and elevated saponin content [[27]](https://www.zotero.org/google-docs/?GXo9kx). It was identified as a resilient genotype in field trials in the Andean highland  and in stressful environments such as saline soils and arid conditions of the Sahara desert [[24,28]](https://www.zotero.org/google-docs/?lJSa25). The founder lines Huariponcho, Pandela Rosada, Pasancalla, and Negra Collana were chosen to maximize allelic diversity, capture adaptive variation, and enhance recombination within each NAM panel.

## Phenotypic evaluation

Phenotypic data were obtained from our previous study [[24]](https://www.zotero.org/google-docs/?pqRcDA), based on multiyear field trials conducted at two experimental sites in the highlands of the province of Puno, Peru, near Lake Titicaca and approximately 40 km apart: Camacani (3,825 m a.s.l.) and Illpa (3,820 m a.s.l.). Phenological and agronomic traits were measured at three developmental stages: flowering (BBCH stage 69), physiological maturity (BBCH stage 89), and harvest (BBCH stage 99), according to the BBCH scale adapted for quinoa [[29]](https://www.zotero.org/google-docs/?QrrGUi). Standard descriptors developed by Biodiversity International [[30]](https://www.zotero.org/google-docs/?cD1kcX) were employed to record traits, including days to 50% flowering (days), days to physiological maturity (days), plant height (cm), stem diameter (cm), panicle length (cm), panicle width (cm), grain yield per plant (g) and yield per plot (g/5 m^2^). Grain yield per plant was estimated using two subsamples of 10 randomly selected plants per experimental unit to ensure representative sampling. Panicle width × length (cm^2^) was included as a trait due to its correlation with yield [[24]](https://www.zotero.org/google-docs/?Mz5pAZ).

Phenotypic data were analyzed using a two-stage mixed model framework as recommended for multi-environment trials [[31,32]](https://www.zotero.org/google-docs/?DXBJWY). In Stage 1, Best Linear Unbiased Estimators (BLUEs) were obtained for each environment by fitting linear mixed models with genotype as a fixed effect and blocks nested within a lattice design as random effects. In Stage 2, Best Linear Unbiased Estimators (BLUEs) and Best Linear Unbiased Predictors (BLUPs) were estimated across environments, modeling genotype as fixed a random effect to account for genotype × environment interactions using function H2cal() implemented in inti R package [[33]](https://www.zotero.org/google-docs/?PusdXp).

## Genotyping and sequence processing

**DNA extraction and sequencing**

Young leaves were sampled from three-month-old field-grown plants at Camacani. For each line, pooled tissue from two plants was dried in silica gel and shipped to the University of Hohenheim (Germany) for DNA extraction using the AX Gravity DNA kit (A&A Biotechnology, Poland). DNA integrity was assessed by agarose gel electrophoresis, and concentration was quantified using Qubit fluorometry (Qubit™ 4 Fluorometer, Thermo Fisher Scientific, USA). Whole-genome sequencing was conducted at Novogene (Beijing, China) using the Illumina NovaSeq S4 platform, generating 2 × 150 bp paired-end reads.

**Read processing, variant calling, and SNP filtering** 

Raw sequencing reads from the 235 retained samples were processed using Trim Galore v0.6.7 [[34]](https://www.zotero.org/google-docs/?UklUiF) with parameters –paired and -q 30 to remove low-quality bases. High-quality reads were aligned to the quinoa reference genome (QQ74; CoGe ID 60716) using BWA-MEM v0.7.17 [[35]](https://www.zotero.org/google-docs/?rbl08g). Resulting BAM files were sorted and indexed with SAMtools v1.8  [[36]](https://www.zotero.org/google-docs/?YN66TH), and duplicate reads were removed using Picard tools ([http://broadinstitute.github.io/picard/](http://broadinstitute.github.io/picard/)). Variant calling was performed using BCFtools v1.11 [[37]](https://www.zotero.org/google-docs/?bNgemC). Variants with more than 50% missing genotypes were filtered out using the expression F\_MISSING > 0.5.

Subsequently, SNP filtering was conducted using the snpR R package [[38]](https://www.zotero.org/google-docs/?gcg8hI), following the recommendations of Hemstrom et al. [[39]](https://www.zotero.org/google-docs/?L4P56e). This included removal of non-polymorphic loci and application of thresholds of min\_ind = 0.5 and min\_loci = 0.75, with stratification by cross (facet = cross). 

## Population structure and genetic diversity

Population structure and genetic diversity indices were estimated using the snpR R package [[38]](https://www.zotero.org/google-docs/?nzA20H). Genotype data were saved and imported into a VCF format as an snpRdata object using import.snpR.data() and then filtered using filter\_snps() under population-specific faceting. Principal component analysis (PCA) was performed via plot\_clusters() to visualize genetic stratification among lines. Ancestry inference was performed using sparse nonnegative matrix factorization (sNMF) within plot\_structure(), testing K values from 2 to 10. The optimal K value was selected based on the minimization of cross-entropy, as recommended for high-dimensional genomic datasets. Genetic diversity indices - observed heterozygosity (H₀), expected heterozygosity (He), inbreeding coefficient (F~IS~) and the proportion of polymorphic loci - were calculated using calc\_ho(), calc\_he(), calc\_fis() and calc\_prop\_poly(). Population differentiation was assessed via pairwise Weir and Cockerham’s F~ST~, estimated via calc\_pairwise\_fst() and visualized as heatmaps.

## Genome-wide association study

Genome-wide association studies (GWAS) were conducted to identify SNP–trait associations underlying yield-related traits in the quinoa NAM populations. To maximize statistical robustness and reduce spurious associations, multiple complementary statistical models were implemented in the rMVP R package [[40]](https://www.zotero.org/google-docs/?mxchu3). The framework was selected because it is memory-efficient, visualization-enhanced, and parallel-accelerated, allowing efficient variance component estimation and large-scale computation. The fixed and random model circulating probability unification (FarmCPU) was used in the analysis [[41]](https://www.zotero.org/google-docs/?4f6IZR). This model combines fixed and random effects while correcting for population structure and kinship, thereby increasing statistical power across loci of varying effect sizes. To control for confounding, the first principal components derived from genome-wide SNP data were included as fixed covariates, while a kinship matrix was incorporated as a random effect. Significance thresholds were determined using Bonferroni threshold for the p-value where $\alpha_{Bonferroni} =m/ \alpha ;\ m=0.05$ and $\alpha$ is the number of SNPs (Supplementary File 1). This multi-model and multi-threshold strategy ensured both sensitivity in detecting true associations and stringency in minimizing false positives. The phenotypic data for the analysis was performed using the BLUEs calculated in the MLT in the second stage from Lozano-Isla et al [[24]](https://www.zotero.org/google-docs/?RlOoNZ) according to Holland & Piepho [[42]](https://www.zotero.org/google-docs/?FjBlSb). 

## Identification of candidate genes associated with significant SNPs

The genomic regions associated with significant SNPs identified in the genome-wide association analysis were further explored to identify potential candidate genes. The physical positions of the significant SNPs were used to define candidate genomic regions in the quinoa reference genome [[43]](https://www.zotero.org/google-docs/?le759B). Genomic windows were defined around each lead SNP to capture nearby genes potentially associated with the trait. A window of ±100 kb around each significant SNP was used to delimit candidate regions.

Gene annotation was obtained from the Chenopodium quinoa reference genome (QQ74) available in the CoGe database (Genome ID 60716; [https://genomevolution.org/coge/GenomeInfo.pl?gid=60716](https://genomevolution.org/coge/GenomeInfo.pl?gid=60716)). The genome annotation file in GFF3 format was imported and processed in R using the packages GenomicRanges [[44]](https://www.zotero.org/google-docs/?DV2E3w) and rtracklayer [[45]](https://www.zotero.org/google-docs/?AujXzE) to manipulate genomic coordinates (Supplementary File 1). Significant SNPs were converted into genomic range objects and expanded to the defined window size. Genomic overlaps between SNP windows and annotated gene coordinates were then identified using interval-based queries, allowing the detection of genes located within each candidate region. For each overlapping feature, gene identifiers and genomic coordinates were extracted to compile a list of candidate genes associated with each significant SNP. 

## Genomic prediction

Genomic prediction was implemented using the genomic best linear unbiased prediction (GBLUP) framework, which is widely used in plant breeding due to its reliability, scalability, and interpretability [[46]](https://www.zotero.org/google-docs/?94xPWp). Marker effects were modeled across the genome using ridge regression BLUP (rrBLUP) [[47]](https://www.zotero.org/google-docs/?6Xo8Wf), allowing the estimation of genomic estimated breeding values (GEBVs) under the assumption of predominantly additive genetic effects. This linear mixed model framework has been widely adopted in genomic selection because it captures a substantial portion of the genetic variance while remaining computationally efficient in high-dimensional datasets [[48]](https://www.zotero.org/google-docs/?Yhy2DS).

To assess predictive ability, cross-validation (CV) was used. In each replicate, 60% of the lines were randomly assigned to the training set for model fitting, while the remaining 40% were allocated to the validation set for prediction. To strengthen the robustness and reproducibility of accuracy estimates, this cross-validation procedure was repeated across 300 resampled prediction sets, each consisting of five independent CV iterations. This resampling strategy has been recommended in recent genomic prediction studies to ensure stable and unbiased evaluations of predictive performance [[46]](https://www.zotero.org/google-docs/?Uw1f31).

Prediction accuracy was quantified with the Pearson correlation between observed phenotypes and genomic estimated breeding values (GEBVs) in the validation set, complemented by the normalized root mean square error (NRMSE) to account for scaling effects  [[49]](https://www.zotero.org/google-docs/?dtU4Ip). The Pearson correlation (r), which ranges from −1 to 1, measures the ability of the model to correctly rank genotypes according to their genetic merit, with values closer to 1 indicating higher predictive ability [[50]](https://www.zotero.org/google-docs/?bZasTF). In contrast, the NRMSE quantifies the magnitude of prediction error relative to the scale of the trait, where values closer to cero indicate greater predictive precision [[51]](https://www.zotero.org/google-docs/?CiLLYZ). 

# RESULTS

## Genetic structure and diversity

To assess the structure and differentiation of each NAM population, principal component analysis (PCA) and population structure analyses were performed, and the fixation index (Fst) was estimated to quantify the degree of population differentiation between both NAM populations ([Figure 2](?tab=t.0#bookmark=id.dy3onpggxou8)). Additionally, diversity indices were calculated for each population, including proportion of polymorphic loci, observed heterozygosity (Ho), expected heterozygosity (He), and the inbreeding coefficient (FIS). 

Low-coverage whole-genome sequencing of 348 lines generated a total of 361.95 Gb of raw data. Quality control at the sample level identified 113 samples with sequencing output below 50 Mb, which were excluded from further analyses. The remaining 235 samples yielded an average of 1.54 Gb per sample, corresponding to approximately 1.06× coverage of the 1.45 Gb quinoa genome  [(Jarvis et al., 2017)](https://www.zotero.org/google-docs/?broken=gW3F7s) (Supplementary Figure 1). After filtering using BCFtools, initial dataset of 396,949 SNPs across the retained samples. At the final stage, filtering by families using snpR R package subset of 125 individuals was retained, resulting in a dataset of 6,046 high-quality SNPs used for subsequent genetic analyses (Supplementary Figure 2)

Principal component analysis (PCA) revealed clear genetic differentiation between the two NAM populations derived from the parental varieties Kancolla (KAN) and Salcedo INIA (SAL) ([Figure 2a](?tab=t.0#bookmark=id.dy3onpggxou8)). The first principal component (PC1), explaining 13.97% of the total variance, separated individuals according to parental origin, with KAN-derived genotypes clustering on the left and SAL-derived genotypes on the right. In contrast, the second principal component (PC2), accounting for 3.05% of the variance, did not reveal a clear pattern of differentiation between groups.

To elucidate the genetic structure and patterns of admixture among biparental families derived from KAN and SAL parental lines, the number of ancestral clusters (K) was inferred using sparse non-negative matrix factorization (sNMF). The number clusters for population structure was inferred for K = 2–10 (Supplementary Figure 3), which identified a stable structure at K = 3 based on the minimum mean cross-entropy criterion ([Figure 2b](?tab=t.0#bookmark=id.dy3onpggxou8)). Across K values, a primary subdivision aligned with parental background (KAN vs. SAL) was consistently recovered, with cross-specific admixture superimposed on this axis. At K = 3, KAN-derived families (NCO×KAN, HUA×KAN, PAS×KAN) were assigned predominantly to Cluster 2 (blue), with PAS×KAN showing the highest homogeneity (near-fixed membership), HUA×KAN displaying intermediate admixture, and NCO×KAN exhibiting the greatest admixture, including contributions from Clusters 1 and 3, and the largest overlap with SAL-derived groups. Conversely, SAL-derived families (SAL×PAN, SAL×HUA, SAL×NCO) showed high membership to Cluster 3 (yellow), with SAL×PAN being the least admixed and only modest contributions from Cluster 2 across SAL crosses. Cluster 1 contributed minimally overall.

Pairwise fixation index (FST) estimates indicated very low genetic differentiation within each parental group and moderate differentiation between groups ([Figure 2c](?tab=t.0#bookmark=id.dy3onpggxou8)). Both Kancolla (KAN)- and Salcedo INIA (SAL)-derived families showed minimal internal structuring with F~ST~-values among KAN-NAM families ranging from 0.004 to 0.014 SAL-NAM from 0.004 to 0.005 whereas consistent differentiation was observed in pairwise comparisons between KAN- and SAL-derived families, with an average of 0.15 reflecting a stronger separation by parental origin, and confirming the PCA.

```Unknown element type at this position: UNSUPPORTED```

![Genetic differentiation of quinoa NAM sub populations. (a) Principal component analysis (PCA) based on genome-wide SNPs. (b) Ancestry estimation for population structure using sparse non-negative matrix factorization (sNMF) at K = 3. (c) Pairwise fixation index (F~ST~) heatmap among NAM subpopulations. For population structure each vertical bar represents an individual, and colors indicate cluster-membership proportions; individuals are grouped by cross: Negra Collana × Kancolla (NCO×KAN), Huariponcho × Kancolla (HUA×KAN), Pasankalla × Kancolla (PAS×KAN), Salcedo INIA × Pandela Rosada (SAL×PAN), Salcedo INIA × Huariponcho (SAL×HUA), and Salcedo INIA × Negra Collana (SAL×NCO).](img_1.jpg){#fig:id.2n0w0hhfgedn}



```Unknown element type at this position: UNSUPPORTED```Genetic diversity indices for the quinoa NAM populations are summarized in [Table 1](?tab=t.0#bookmark=id.7a6p5h1zcwu2). At the population level, KAN and SAL showed comparable levels of observed heterozygosity (Hₒ = 0.14 in KAN and 0.13 in SAL). Expected heterozygosity (Hₑ) was similar in both populations (0.12 in KAN and 0.11 in SAL). In both cases, observed heterozygosity exceeded expected heterozygosity, resulting in negative inbreeding coefficients (FIS = −0.19 in KAN and −0.21 in SAL), indicating heterozygote excess within the NAM populations.

Across the individual crosses, observed heterozygosity varied between 0.13 and 0.14 across families and consistently exceeded expected heterozygosity (0.10–0.12). As a consequence, all crosses showed negative FIS values, ranging from −0.17 to −0.24. The strongest heterozygote excess was observed in SAL×PAN (FIS = −0.24), followed by NCO×KAN and SAL×HUA (both FIS = −0.21), while HUA×KAN showed the least negative value (FIS = −0.17).

The proportion of polymorphic loci (poly) revealed high levels of genetic variability in the parental populations, with values of 0.95 for KAN and 0.93 for SAL. In contrast, the derived NAM crosses exhibited slightly lower poly values, ranging from 0.67 to 0.76. Among these, PAS×KAN showed the highest proportion of polymorphic loci (0.76), followed by HUA×KAN and NCO×KAN (0.71), whereas SAL-derived crosses such as SAL×HUA, SAL×NCO, and SAL×PAN presented comparatively lower values (0.69, 0.72, and 0.67, respectively).




| **Population** | **ho**         | **he**         | **fis**        | **poly**       | **n**           |
|----------------|----------------|----------------|----------------|----------------|-----------------|
| NAM            |                |                |                |                |                 |
| KAN            | 0.14           | 0.12           | -0.19          | 0.95           | 60              |
| SAL            | 0.13           | 0.11           | -0.21          | 0.93           | 65              |
| Cross          |                |                |                |                |                 |
| HUAxKAN        | 0.14           | 0.12           | -0.17          | 0.71           | 18              |
| NCOxKAN        | 0.13           | 0.11           | -0.21          | 0.71           | 21              |
| PASxKAN        | 0.14           | 0.12           | -0.2           | 0.76           | 21              |
| SALxHUA        | 0.14           | 0.11           | -0.21          | 0.69           | 19              |
| SALxNCO        | 0.13           | 0.1            | -0.2           | 0.72           | 26              |
| SALxPAN        | 0.13           | 0.1            | -0.24          | 0.67           | 20              |




: Genetic diversity indices for quinoa NAM populations. Observed heterozygosity (Hₒ), expected heterozygosity (Hₑ), inbreeding coefficient (FIS), proportion of polymorphic loci (poly), and number of individuals (n = 125). {#tbl:id.7a6p5h1zcwu2}

## 

## Mapping of QTL associated with yield architecture in NAM populations

We conducted a genome-wide association study (GWAS) to identify quantitative trait loci (QTLs) associated with key components of quinoa yield architecture across nested association mapping (NAM) families derived from Salcedo INIA (SAL) and Kancolla (KAN), respectively ([Figure  @fig:id.ysu94l6l37zq]:). The phenotypic traits used in the GWAS were analyzed using the best linear unbiased estimates (BLUEs; [[32]](https://www.zotero.org/google-docs/?jNlXtC). Most trait  distributions approximated a normal distribution  (Supplementary Figure 4), particularly those related to plant architecture and yield components (plant height, panicle length and width, stem diameter, grain yield per plant, and grain yield per plot). In contrast, traits associated with phenology (number of days to 50% flowering and physiological maturity) deviated from normality, reflecting their intrinsic biological nature as time-to-event variables with discrete and often skewed distributions.

GWAS using FarmCPU identified 26 SNPs significantly associated with yield-related traits across the quinoa NAM populations ([Figure  @fig:id.ysu94l6l37zq]:, Supplementary Table 3). Of these, 21 SNPs were detected in the KAN-NAM population and five in the SAL-NAM population. All 26 SNPs exceeded the Bonferroni significance threshold (p < 8 × 10⁻⁶). Phenological traits showed the highest number of associations, with 11 SNPs linked to flowering and maturity time (five for days to 50% flowering and six for days to 50% physiological maturity;  [Figure 3a,g](?tab=t.0#bookmark=id.ysu94l6l37zq)). Architectural traits, including plant height and panicle length, accounted for 12 significant associations across developmental stages. In contrast, yield traits were represented by three SNPs associated with grain yield per plot, all of which were population-specific and predominantly identified in the KAN-NAM population (Figure 3). No significant associations were detected for panicle width at maturity or for the panicle width × length trait.

To validate the GWAS signals, QQ plots were examined for each trait (Supplementary Figure 5). The observed distributions of −log₁₀(p) closely followed the expected null distribution across most traits, confirming that the models effectively controlled for population structure and relatedness. Deviations from the null expectation were evident in the tails for flowering time, physiological maturity, panicle length and panicle width, reflecting the presence of true associations rather than spurious signals. In contrast, yield-related traits grain yield per plant, yield per plot and panicle width x length showed only modest departures from expectation, consistent with their lower number of significant SNPs. Together, the Manhattan and QQ plots demonstrate that the detected loci represent reliable associations, especially for phenological traits with strong genetic signals in the KAN-NAM population.

An additional association analysis was performed using the R package NAM, which is specifically designed for nested association mapping populations [[52]](https://www.zotero.org/google-docs/?mSqH41). The Manhattan plots showed no peaks surpassing the Bonferroni thresholds (Supplementary Figure 6). The QQ plots (Supplementary Figure 7) further confirmed this outcome, as the observed −log₁₀(p) values largely fell below the expected distribution under the null hypothesis, indicating an overall conservative model fit. The NAM implementation did not uncover additional associations beyond those identified with the rMVP package [[53]](https://www.zotero.org/google-docs/?EZkAuR).

```Unknown element type at this position: UNSUPPORTED```

![Genome-wide association study for yield-related traits in quinoa (*Chenopodium quinoa*) in two NAM populations evaluated at two locations in the Peruvian highlands. (a) Number of days to 50% flowering (days, ndflw), (b) Plant height at flowering (cm, plth\_flw), (c) Panicle length at flowering (cm, pnlg\_flw), (d) Panicle width at flowering (cm, pnwd), (e) Panicle length at maturity (cm, pnlg\_mtr ), (f) Plant height at maturity (cm, plth\_mtr), (g) Number of days to 50% physiological maturity (days, ndpm\_mtr), and (h) Grain yield per plot (g/5m^2^, yplt\_hrv) Orange and green points denote SAL- and KAN-derived NAM populations, respectively (n = 125). The horizontal line indicates the genome-wide significance at Bonferroni threshold (p-value < 0.000008). $\alpha_{Bonferroni}=\frac{m}{\alpha};\ m=0.05,\ \alpha=6046\ snps$.](img_2.jpg){#fig:id.ysu94l6l37zq}



```Unknown element type at this position: UNSUPPORTED```## Identification of candidate genes associated with significant SNPs

A total of 68 candidate genes were identified within ±100 kb genomic windows surrounding significant SNPs detected in the GWAS analysis (Supplementary Table 4). Candidate genes were distributed across nine quinoa chromosomes (Supplementary Table 4), with the largest number located on chromosome Cq6A (37 genes), followed by Cq9A (9 genes), Cq5A (8 genes), and Cq2A (5 genes), while fewer genes were detected on Cq7B, Cq8B, Cq3B, Cq5B, and Cq6B. Across traits, the largest number of candidate genes was associated with days to 50% flowering (16 genes) and physiological maturity (14 genes), followed by panicle width (12 genes) and panicle length (12 genes). A smaller number of genes were detected for grain yield per plot (9 genes) and plant height at flowering (5 genes).

For plant height, candidate genes included DIR19 and DIR7, which encode dirigent proteins involved in cell wall formation, together with RPL5, a ribosomal protein associated with cellular growth. For panicle architecture traits, genes such as CRF2, CIP1, and metabolic enzymes including 6-phosphogluconate dehydrogenase were identified. Phenological traits were associated with genes involved in signaling and transcriptional regulation, including LECRK2 and SR-like splicing factor 1, whereas grain yield per plot was linked to genes related to cellular transport and metabolic regulation such as ABC transporter G family member 3, SNF1-related protein kinase regulatory subunit β3, and VPS32 (Supplementary Table 4) .

## Genomic prediction in NAM population

Assessing genomic prediction performance in structured populations is important for determining the potential use of genomic information in breeding programs and for understanding how population structure may influence predictive ability. To evaluate the potential of genomic prediction in two nested association mapping (NAM) populations, prediction accuracy and normalized root mean square error (NRMSE) were estimated for nine agronomic and yield-related traits. Training and validation datasets were defined using a 60/40 split (n = 125; 60 lines from KAN and 65 from SAL). For each trait, 300 independent iterations were conducted to obtain stable estimates of predictive performance (Figure 4). 

The KAN population showed higher predictive performance than SAL across most traits. Mean prediction accuracies averaged across traits were approximately 0.39 in KAN and 0.24 in SAL, indicating differences in predictive capacity between populations. These contrasts were statistically significant (p < 0.001, Supplementary Table 5). Consistent with the accuracy results, NRMSE values were generally lower in KAN than in SAL. For example, mean NRMSE values for days to 50% flowering were 0.75 in KAN and 1.00 in SAL, while days to physiological maturity showed values of 0.76 and 0.97, respectively. Similarly, plant height at maturity presented mean NRMSE values of 0.98 in KAN and 1.02 in SAL. Significant differences between populations were detected for most traits (p < 0.001), with the exception of mean stem diameter at maturity, where NRMSE values were similar between populations (1.02; p = 0.70). For panicle width at maturity, NRMSE values were 1.01 in KAN and 0.98 in SAL, and the difference between populations was significant (p < 0.001).

At the trait level, the highest prediction accuracies in KAN were observed for phenological traits and inflorescence architecture. Days to 50% flowering showed a mean accuracy of 0.80 (range: 0.58–0.93), while days to physiological maturity presented a mean of 0.80 (0.54–0.93). Panicle length at flowering (pnlg\_flw) also showed relatively high predictive ability, with a mean accuracy of 0.78 (0.42–0.91). Yield-related traits showed moderate predictive performance in KAN, with mean accuracies of 0.52 (0.07–0.75) for yield per plot and 0.32 (−0.10–0.67) for grain yield per plant.

Predictive performance in the SAL population was generally lower. For example, mean accuracies were approximately 0.28 for panicle length at flowering, 0.34 for panicle length at maturity, and 0.26 for yield per plot, indicating reduced predictive ability under the applied validation scheme. An exception was observed for panicle width at maturity, where SAL showed a higher mean accuracy (0.33) compared with KAN (−0.11), although this difference was not supported by improvements in NRMSE. Mean stem diameter at maturity showed low predictive performance in both populations, with mean accuracies of approximately 0.09 in KAN and −0.06 in SAL.

![Genomic prediction accuracy for yield-related traits in quinoa (Chenopodium quinoa) across two nested association mapping (NAM) populations. Mean stem diameter (cm), days to 50% flowering (days), days to 50% physiological maturity (days), plant height (cm) at flowering and maturity, panicle length (cm), panicle width (cm) at flowering and maturity, grain yield per plant (g), panicle width × length (cm^2^) and yield per plot (g/5m^2^). Training and validation sets were split in a 60/40 proportion with 60 individuals from the KAN population and 65 from the SAL population (n = 125). For each trait, 300 iterations were performed, and boxplots represent the distributions of prediction accuracy.](img_3.jpg){#fig:id.v28mocce7c8c}



# DISCUSSION

This study presents the first implementation of nested association mapping (NAM) in quinoa, providing a genomic resource to dissect the genetic architecture of yield-related traits in germplasm from the Andean highlands. By combining the two different recurrent parents Salcedo INIA, a widely cultivated improved variety, and Kancolla, a traditional highland landrace, with diverse founder lines from the Peruvian highlands, the NAM populations were designed to include broad allelic variation associated with phenology, plant architecture, and yield components. The integration of multi-environment phenotyping, genome-wide SNP data, and association studies enabled the identification of genomic regions contributing to agronomic trait variation while simultaneously revealing the population structure and genetic diversity underlying this breeding material. Genomic prediction allowed to evaluate the potential of genomic selection in these structured populations. 

## Genetic diversity and population structure in NAM population

The assessment of genetic structure and diversity revealed clear differentiation between SAL- and KAN-derived populations, reflecting their divergent breeding histories and adaptation to the environmental conditions of the highland. Salcedo INIA is a high-yielding, disease- and frost-resistant cultivar, while Kancolla is a traditional landrace noted for its stress tolerance and high saponin content [[24]](https://www.zotero.org/google-docs/?06xn27). Principal component analysis and ancestry inference consistently separated families according to parental origin, while pairwise F~ST~ values confirmed divergence between populations but low differentiation within families (Figure 2). Genetic diversity estimates indicated moderate variability, and consistently negative inbreeding coefficients pointed to a heterozygosity across the populations ([Table 1](?tab=t.0#bookmark=id.7a6p5h1zcwu2)). In the context of the advanced inbreeding generation of the material analyzed (S9), where a high level of homozygosity is expected; however, the residual heterozygosity and negative FIS values reflect the multi-parental origin of the NAM design and the persistence of segregating genomic regions due to recombination among diverse founders.

Patiranage et al. [[18]](https://www.zotero.org/google-docs/?lkFfMt) reported low levels of nucleotide diversity (π) in quinoa accessions from highland and lowland populations, with values of 0.000578 and 0.000356, respectively, which is a typical representation of self-pollinated species such as quinoa. These estimates were obtained from high-quality whole-genome resequencing data, which likely provide an accurate representation of the genetic diversity of quinoa than that captured in the present study. In contrast, the present study does not rely on nucleotide diversity estimates but on marker-based diversity using the proportion of polymorphic loci, which reflects allelic variation at the genotyped loci rather than genome-wide sequence diversity. The results obtained in our study showed high proportions of polymorphic loci in the parental lines ([Table 1](?tab=t.0#bookmark=id.7a6p5h1zcwu2)) and moderately reduced in the NAM-derived families, indicating that a considerable fraction of segregating variation was retained across populations ([Table 1](?tab=t.0#bookmark=id.7a6p5h1zcwu2)). KAN-derived crosses tended to exhibit a higher proportion of polymorphic loci values compared to SAL-derived crosses, suggesting a greater contribution or retention of polymorphic segments from the KAN background. Additionally, the relatively narrow range of proportion of polymorphic loci values among crosses indicates a homogeneous distribution of introgressed variation across the NAM population, despite differences in parental origin. This pattern reflects the biparental crossing design and recent recombination events inherent to NAM populations rather than population subdivision. 

The high admixture coefficients observed in some KAN- or SAL-derived individuals reflect limited introgression, whereas intermediate coefficients correspond to a greater contribution of alleles from multiple founder parents. Consequently, negative FIS values were detected, indicating an excess of heterozygotes relative to Hardy–Weinberg expectations ([Table 1](?tab=t.0#bookmark=id.7a6p5h1zcwu2)). This pattern likely reflects the biparental crossing design and recent recombination events inherent to NAM populations rather than population subdivision. Additionally, FST estimates revealed differentiation between the SAL- and KAN-derived groups but little divergence within families (Figure 2). In contrast, a study conducted in Colombia that assessed the genetic diversity of quinoa using 27 microsatellite markers across three groups classified according to their geographic origin reported high expected heterozygosity values, ranging from 0.58 to 0.62 [[54]](https://www.zotero.org/google-docs/?BXEN9p). 

## QTL for yield-related traits 

The genome-wide association analysis identified 26 significant SNPs associated with eight agronomic traits ([Figure  @fig:id.ysu94l6l37zq]:), revealing genomic regions contributing to phenological development, plant architecture, and yield-related traits in quinoa. These traits, including flowering time, plant height, panicle morphology, and grain yield, have previously been identified as key targets for genetic improvement due to their relatively high heritability and direct contribution to yield potential [[17,24,55,56]](https://www.zotero.org/google-docs/?sFfMmg). The detection of multiple loci across traits is consistent with the polygenic architecture of yield formation in quinoa, where complex agronomic traits are controlled by numerous loci with small to moderate effects, as reported in previous QTL and GWAS studies  [[14]](https://www.zotero.org/google-docs/?6uRIID).

The detected associations presented an uneven distribution of QTL between NAM subpopulations, with the majority identified in the KAN-derived families. Landraces are known to harbor extensive allelic diversity associated with environmental adaptation, which can increase the probability of detecting trait-associated loci in mapping populations [[57]](https://www.zotero.org/google-docs/?hOoGGB). When comparing the genomic positions of the SNPs detected in this study (SupplementaryTable 3) with loci reported in previous quinoa mapping studies (Supplementary Table 6), several overlapping chromosomal regions were identified, suggesting the presence of conserved genomic regions controlling agronomic traits. In particular, associations were detected on chromosomes Cq5A, Cq6A and Cq9A, which have been implicated in the regulation of phenology, plant architecture, and yield-related traits in quinoa populations [[14,58,59]](https://www.zotero.org/google-docs/?y1WYJf).

For phenological traits such as days to 50% flowering and physiological maturity, significant SNPs detected in this study were located on chromosomes including Cq5A, Cq5B, Cq6A, and Cq7B, overlapping with genomic regions previously associated with flowering time in diverse quinoa germplasm panels. Earlier studies have reported QTL controlling flowering time on chromosomes Cq2A, Cq5A, and Cq6A, suggesting that these genomic regions may harbor conserved regulatory elements involved in developmental timing and environmental adaptation [[18,60]](https://www.zotero.org/google-docs/?v5Za7x). The recurrence of associations on these chromosomes across independent studies supports the hypothesis that phenological adaptation in quinoa could be mediated by stable genomic regions maintained across different genetic backgrounds (Supplementary Table 6).

Yield-related traits exhibited fewer significant associations, with SNPs detected mainly on Cq6B and Cq9A. This result is consistent with previous findings indicating that grain yield in quinoa is a highly complex trait influenced by many loci with small effects and strong environmental interactions [[60]](https://www.zotero.org/google-docs/?EIUtQh). The limited number of yield-associated SNPs detected in this study likely reflects both the polygenic nature of yield and the moderate population size typical of NAM populations in emerging crops. Nevertheless, the detection of loci on genomic regions previously linked to yield components reinforces their potential importance for breeding applications.

The genomic regions identified in this study were distributed across several chromosomes, with a notable concentration on Cq6A, Cq5A, and Cq9A, suggesting that key genomic regions contribute trait variation in the quinoa NAM population. Within these regions, candidate genes with biological functions related to the studied traits were identified. Loci associated with plant height were located near genes encoding dirigent proteins (DIR19 and DIR7) and ribosomal proteins, which participate in lignin biosynthesis and cellular growth processes influencing stem elongation and plant architecture [[61,62]](https://www.zotero.org/google-docs/?3IRmPt). For panicle morphology traits, including panicle length and width, candidate genes included cytokinin response factors and metabolic enzymes, which are known to regulate hormonal signaling and developmental processes involved in inflorescence formation [[63–65]](https://www.zotero.org/google-docs/?B51Cy9). For phenological traits, such as flowering time and physiological maturity, candidate genes included receptor-like kinases and RNA splicing factors [[66–68]](https://www.zotero.org/google-docs/?5qrXiK), suggesting that signaling pathways and transcriptional regulation may play a role in controlling developmental timing in quinoa. Loci associated with grain yield were located near genes involved in membrane transport and metabolic regulation, including ABC transporters and SNF1-related kinases, highlighting the importance of energy balance and cellular transport processes in yield determination [[69–71]](https://www.zotero.org/google-docs/?bnlBBl). These functional annotations detect genomic associations and provide a preliminary framework for identifying genes underlying agronomic trait variation.

These findings across independent studies reinforces the genetic basis of yield in quinoa is structured by a set of moderate- to large-effect regions stable across populations. These regions could represent strategic targets for marker-assisted selection in breeding programs focused on productivity and climatic adaptation for early maturity.

## Genomic prediction in NAM populations

Genomic prediction was implemented in the quinoa NAM population to highlight the breeding potential. The simulations showed prediction accuracies ranged from low (-0.16) to high (0.8) across traits and population, demonstrating their application on quinoa. Accuracy distributions in KAN are consistently centered at higher, positive values for phenological and architectural traits (number of days to 50% flowering, number of days to 50% physiological maturity, and panicle length at maturity), whereas in SAL toward low or negative values and display greater dispersion (Figure 4). 

The presence of negative prediction accuracies for some traits, particularly in the SAL population, indicates that the genomic model failed to predict phenotypic variation better than random expectation in those cases. Negative correlations between observed phenotypes and predicted GEBVs can arise when training population size is limited, marker density is insufficient, or when the genetic architecture of the trait is highly complex and influenced by environmental variation [[50,72]](https://www.zotero.org/google-docs/?IhwBQf). In this case, the results of the present study could be explained by the relatively small population size and the moderate marker density derived from low-coverage sequencing, which may limit the ability of the model to capture the underlying genetic signal. Such results do not necessarily invalidate the model but rather highlight limitations in prediction power under the current population structure and dataset size. 

The results converge on higher model capacity for phenology and inflorescence architecture – particularly in KAN – and moderate performance for yield traits; SAL shows low accuracies and elevated NRMSEs for most traits, with few exceptions and without significant differences where they occur. In addition to prediction accuracy, model performance was evaluated using the normalized root mean square error (NRMSE), which quantifies the magnitude of prediction error relative to the scale of the observed trait values. Lower NRMSE values indicate greater predictive precision and smaller deviations between predicted and observed phenotypes [[49,51]](https://www.zotero.org/google-docs/?BjVXWV). These findings support prioritizing traits such as number of days to 50% flowering, number of days to 50% physiological maturity, and panicle length at maturity, and indicate the need for targeted strategies – e.g., increased sample size, marker enrichment, or multi-environment models – to improve predictability in SAL population.

In our previous study conducted with the same NAM populations, variance components and broad-sense heritability were estimated  [[24]](https://www.zotero.org/google-docs/?8g8O90). Within this context, traits with high heritability, such as days to maturity (H² = 0.95), days to flowering (H² = 0.91), grain width (H² = 0.94), and plant height at maturity (H² = 0.88), also achieved the highest prediction accuracies (i.e. 0.6–0.9), indicating that a substantial proportion of the phenotypic variance is attributable to genetic effects captured by molecular markers. In contrast, traits with intermediate or low heritability, such as plant height at flowering (H² = 0.45), panicle width at flowering (H² = 0.46), and harvest index (H² = 0.72), exhibited lower prediction accuracies (i.e. 0.1–0.4), reflecting a greater contribution of residual variance and genotype × environment interaction. In particular, traits associated with morphological components at early developmental stages showed higher contributions of error varianceₑ and genotype × location variance, which reduces the stability of genetic effects across environments and consequently limits predictive performance [[73]](https://www.zotero.org/google-docs/?txbClh). A particularly relevant case was grain yield, which, despite presenting relatively high heritability (H² = 0.84), showed only moderate prediction accuracy (i.e. 0.3–0.5). This discrepancy can be explained by its considerable interaction component genotype × location variance and residual variance, indicating a complex, likely polygenic genetic architecture. 

These differences between populations likely reflect contrasting genetic architectures and trait heritabilities between highland cultivars and traditional landraces backgrounds [[24]](https://www.zotero.org/google-docs/?PXglbi). Importantly, high prediction accuracies were achieved despite moderate marker density and low sequencing depth, outcomes consistent with results in other cereals and legumes [[46,48]](https://www.zotero.org/google-docs/?rdVHRx). The findings confirm that genomic prediction can be implemented in quinoa breeding pipelines to accelerate genetic gain. Even if we used the two stage approach for the analysis [[42]](https://www.zotero.org/google-docs/?sQqtIc). The integration of genomic prediction under multi-environment trials is particularly relevant, as it allows for the explicit modeling of genotype × environment interactions, which play a key role in determining yield stability across environments  [[31]](https://www.zotero.org/google-docs/?D8JkaK).

The observed prediction accuracies indicate that genomic prediction can be effectively implemented in quinoa NAM populations, particularly for phenological and architectural traits. The higher predictive performance detected in the KAN population suggests that genetic background and population structure influence model efficiency, highlighting the importance of population-specific training in genomic selection frameworks. Our results demonstrate the practical applicability of genomic selection in quinoa and highlight its potential to enhance selection strategies in Andean germplasm.

## Limitations and perspectives

Despite the results, some limitations of the study must be acknowledged. The sequencing depth (\~1× coverage) constrained the resolution of variant calling and may have led to underrepresentation of rare alleles. Higher coverage resequencing would improve marker density and accuracy [[74]](https://www.zotero.org/google-docs/?zzgDzJ). The number of parental lines in this quinoa NAM population is smaller than in classical designs such as the original maize NAM population [[75]](https://www.zotero.org/google-docs/?KZv3PY), which included 25 founders crossed to a single reference line. The reduced number of individuals per population could decrease the statistical power for GWAS and genomic prediction analyses. Nevertheless, the smaller population size is offset by the high genetic divergence between parental lines, ensuring allelic diversity for effective QTL detection. The field evaluations were restricted to two highland sites in Puno, which limited the exploration of genotype × environment interactions on inter-Andean valley or coastal ecological regions of Peru [[24]](https://www.zotero.org/google-docs/?LvbVVj). The NAM populations were derived from four different founders and still represent only a fraction of the genetic base available in the Andes. Future research should explore advanced modeling approaches, including deep learning architectures tailored to small datasets, to enhance genomic prediction accuracy [[46]](https://www.zotero.org/google-docs/?xmSnbI). While prediction accuracies were encouraging, they should be interpreted cautiously due to relatively small training population sizes. Larger training sets and integration of advanced modeling approaches such as deep learning may further enhance predictive power [[46,72]](https://www.zotero.org/google-docs/?o0XabS). 

# CONCLUSION

This study establishes a nested association mapping (NAM) approach in Chenopodium quinoa and provides insights into the genetic architecture of yield-related traits in Andean germplasm. Genetic differentiation between Salcedo INIA– and Kancolla–derived families reflects the contribution of contrasting genetic backgrounds of improved cultivars and traditional landraces. Genome-wide association analyses confirm the polygenic nature of key agronomic traits and identify genomic regions associated with phenological, architectural, and yield-related traits, with an important contribution from landrace-derived alleles, particularly within the Kancolla background. Genomic prediction showed moderate-to-high accuracy, with higher performance for phenological and architectural traits, indicating its potential for implementation in quinoa breeding programs. These results support the integration of NAM populations with GWAS and genomic prediction as a strategy to improve selection efficiency and facilitate the development of new quinoa cultivars adapted to the environmental conditions of the Peruvian highlands.

# REFERENCES

[1.](https://www.zotero.org/google-docs/?q8N38D)	[Ali, A. A., Ali, A. H., Nassar, M. A., Elgeilany, S. M. & Ezzat, S. M. Quinoa as a functional crop with emphasis on distribution, nutritional composition, and biological effects. *Discov. Food* **5**, 285 (2025). ](https://www.zotero.org/google-docs/?q8N38D)

[2.](https://www.zotero.org/google-docs/?q8N38D)	[Hinojosa, L., González, J. A., Barrios-Masias, F. H., Fuentes, F. & Murphy, K. M. Quinoa Abiotic Stress Responses: A Review. *Plants* **7**, 106 (2018). ](https://www.zotero.org/google-docs/?q8N38D)

[3.](https://www.zotero.org/google-docs/?q8N38D)	[Dehghanian, Z. *et al.* Quinoa: A Promising Crop for Resolving the Bottleneck of Cultivation in Soils Affected by Multiple Environmental Abiotic Stresses. *Plants* **13**, 2117 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[4.](https://www.zotero.org/google-docs/?q8N38D)	[Cocozza, C. *et al.* Effects of Increasing Salinity Stress and Decreasing Water Availability on Ecophysiological Traits of Quinoa (Chenopodium quinoa Willd.) Grown in a Mediterranean-Type Agroecosystem. *J. Agron. Crop Sci.* **199**, 229–240 (2013). ](https://www.zotero.org/google-docs/?q8N38D)

[5.](https://www.zotero.org/google-docs/?q8N38D)	[Jacobsen, S.-E., Mujica, A. & Jensen, C. R. The Resistance of Quinoa (Chenopodium quinoaWilld.) to Adverse Abiotic Factors. *Food Rev. Int.* **19**, 99–109 (2003). ](https://www.zotero.org/google-docs/?q8N38D)

[6.](https://www.zotero.org/google-docs/?q8N38D)	[Nhamo, N. & Talabi, A. O. Pseudocereals as Superfoods: Complementarity with No Competition for Food and Nutrition Security. in *Smart Food Industry: The Blockchain for Sustainable Engineering* 49–65 (CRC Press, 2024). ](https://www.zotero.org/google-docs/?q8N38D)

[7.](https://www.zotero.org/google-docs/?q8N38D)	[Serrat, X., Quello, A., Manikan, B., Lino, G. & Nogués, S. Comparative Salt-Stress Responses in Salt-Tolerant (Vikinga) and Salt-Sensitive (Regalona) Quinoa Varieties. Physiological, Anatomical and Biochemical Perspectives. *Agronomy* **14**, 3003 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[8.](https://www.zotero.org/google-docs/?q8N38D)	[Yang, A., Akhtar, S. S., Amjad, M., Iqbal, S. & Jacobsen, S.-E. Growth and Physiological Responses of Quinoa to Drought and Temperature Stress. *J. Agron. Crop Sci.* **202**, 445–453 (2016). ](https://www.zotero.org/google-docs/?q8N38D)

[9.](https://www.zotero.org/google-docs/?q8N38D)	[Alandia, G., Rodriguez, J. P., Jacobsen, S.-E., Bazile, D. & Condori, B. Global expansion of quinoa and challenges for the Andean region. *Glob. Food Secur.* **26**, 100429 (2020). ](https://www.zotero.org/google-docs/?q8N38D)

[10.](https://www.zotero.org/google-docs/?q8N38D)	[Bazile, D. Global Trends in the Worldwide Expansion of Quinoa Cultivation. in *la ValSe-Food 2023* 13 (MDPI, 2023). doi:10.3390/blsf2023025013. ](https://www.zotero.org/google-docs/?q8N38D)

[11.](https://www.zotero.org/google-docs/?q8N38D)	[Afzal, I., Haq, M. Z. U., Ahmed, S., Hirich, A. & Bazile, D. Challenges and Perspectives for Integrating Quinoa into the Agri-Food System. *Plants* **12**, 3361 (2023). ](https://www.zotero.org/google-docs/?q8N38D)

[12.](https://www.zotero.org/google-docs/?q8N38D)	[Colque-Little, C. *et al.* Genetic variation for tolerance to the downy mildew pathogen Peronospora variabilis in genetic resources of quinoa (Chenopodium quinoa). *BMC Plant Biol.* **21**, 41 (2021). ](https://www.zotero.org/google-docs/?q8N38D)

[13.](https://www.zotero.org/google-docs/?q8N38D)	[Fondevilla, S., Calderón-González, Á., Rojas-Panadero, B., Cruz, V. & Matías, J. Genome-wide association study, combined with bulk segregant analysis, identify plant receptors and defense related genes as candidate genes for downy mildew resistance in quinoa. *BMC Plant Biol.* **24**, 594 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[14.](https://www.zotero.org/google-docs/?q8N38D)	[Maldonado-Taipe, N., Barbier, F., Schmid, K., Jung, C. & Emrani, N. High-Density Mapping of Quantitative Trait Loci Controlling Agronomically Important Traits in Quinoa (Chenopodium quinoa Willd.). *Front. Plant Sci.* **13**, 916067 (2022). ](https://www.zotero.org/google-docs/?q8N38D)

[15.](https://www.zotero.org/google-docs/?q8N38D)	[Huang, L. *et al.* Comparative transcriptomes and WGCNA reveal hub genes for spike germination in different quinoa lines. *BMC Genomics* **25**, 1231 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[16.](https://www.zotero.org/google-docs/?q8N38D)	[Li, H. *et al.* Genome-wide identification of the AAT gene family in quinoa and analysis of its expression pattern under abiotic stresses. *BMC Genomics* **26**, 298 (2025). ](https://www.zotero.org/google-docs/?q8N38D)

[17.](https://www.zotero.org/google-docs/?q8N38D)	[Lozano-Isla, F., Kienbaum, L., Haussmann, B. I. G. & Schmid, K. A High-Throughput Phenotyping Pipeline for Quinoa (*Chenopodium quinoa*) Panicles Using Image Analysis With Convolutional Neural Networks. *Plant Breed.* https://doi.org/10.1111/pbr.13266 (2025) doi:10.1111/pbr.13266. ](https://www.zotero.org/google-docs/?q8N38D)

[18.](https://www.zotero.org/google-docs/?q8N38D)	[Patiranage, D. S. *et al.* Genome-wide association study in quinoa reveals selection pattern typical for crops with a short breeding history. *eLife* **11**, e66873 (2022). ](https://www.zotero.org/google-docs/?q8N38D)

[19.](https://www.zotero.org/google-docs/?q8N38D)	[Maughan, P. J. *et al.* A genetic linkage map of quinoa (Chenopodium quinoa) based on AFLP, RAPD, and SSR markers. *Theor. Appl. Genet.* **109**, 1188–1195 (2004). ](https://www.zotero.org/google-docs/?q8N38D)

[20.](https://www.zotero.org/google-docs/?q8N38D)	[Yu, J., Holland, J. B., McMullen, M. D. & Buckler, E. S. Genetic Design and Statistical Power of Nested Association Mapping in Maize. *Genetics* **178**, 539–551 (2008). ](https://www.zotero.org/google-docs/?q8N38D)

[21.](https://www.zotero.org/google-docs/?q8N38D)	[Chidzanga, C., Mullan, D., Roy, S., Baumann, U. & Garcia, M. Nested association mapping-based GWAS for grain yield and related traits in wheat grown under diverse Australian environments. *Theor. Appl. Genet.* **135**, 4437–4456 (2022). ](https://www.zotero.org/google-docs/?q8N38D)

[22.](https://www.zotero.org/google-docs/?q8N38D)	[Hu, J. *et al.* Genetic Properties of a Nested Association Mapping Population Constructed With Semi-Winter and Spring Oilseed Rapes. *Front. Plant Sci.* **9**, 1740 (2018). ](https://www.zotero.org/google-docs/?q8N38D)

[23.](https://www.zotero.org/google-docs/?q8N38D)	[Kitony, J. K. *et al.* Development of an Aus-Derived Nested Association Mapping (Aus-NAM) Population in Rice. *Plants* **10**, 1255 (2021). ](https://www.zotero.org/google-docs/?q8N38D)

[24.](https://www.zotero.org/google-docs/?q8N38D)	[Lozano-Isla, F. *et al.* Enhancing quinoa cultivation in the Andean highlands of Peru: a breeding strategy for improved yield and early maturity adaptation to climate change using traditional cultivars. *Euphytica* **219**, 26 (2023). ](https://www.zotero.org/google-docs/?q8N38D)

[25.](https://www.zotero.org/google-docs/?q8N38D)	[Mujica, A., Jacobsen, S. E., Izquierdo, J. & Marathee, J. P. Resultados de la Prueba Americana y Europea de la Quinua. *FAO UNA-Puno CIP* **51**, (2001). ](https://www.zotero.org/google-docs/?q8N38D)

[26.](https://www.zotero.org/google-docs/?q8N38D)	[Zapana-Yucra, F., Guerra Lima, R. S., Medina Espinoza, W. & Prieto, J. M. Sorption isotherms and physical properties of three quinoa varieties grown at two altitudes. *Braz. J. Food Technol.* **28**, e2024053 (2025). ](https://www.zotero.org/google-docs/?q8N38D)

[27.](https://www.zotero.org/google-docs/?q8N38D)	[Shams, A. S. Preliminary Evaluation of New Quinoa Genotypes under Sandy Soil Conditions in Egypt. *Agric. Sci.* **09**, 1444–1456 (2018). ](https://www.zotero.org/google-docs/?q8N38D)

[28.](https://www.zotero.org/google-docs/?q8N38D)	[Maamri, K., Zidane, O. D., Chaabena, A., Fiene, G. & Bazile, D. Adaptation of Some Quinoa Genotypes (Chenopodium quinoa Willd.), Grown in a Saharan Climate in Algeria. *Life* **12**, 1854 (2022). ](https://www.zotero.org/google-docs/?q8N38D)

[29.](https://www.zotero.org/google-docs/?q8N38D)	[Sosa‐Zuniga, V., Brito, V., Fuentes, F. & Steinfort, U. Phenological growth stages of quinoa (*Chenopodium quinoa*) based on the BBCH scale. *Ann. Appl. Biol.* **171**, 117–124 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[30.](https://www.zotero.org/google-docs/?q8N38D)	[Bioversity International, Fundación para la Promoción e Investigación de Productos Andinos, Instituto Nacional de Innovación Agropecuaria y Forestal, International Fund for Agricultural Development, & Food and Agriculture Organization of the United Nations. *Descriptors for Quinoa  (*Chenopodium Quinoa *Willd) and Wild Relatives*. (Bioversity International, 2013). ](https://www.zotero.org/google-docs/?q8N38D)

[31.](https://www.zotero.org/google-docs/?q8N38D)	[Buntaran, H. *et al.* Cross‐validation of stagewise mixed‐model analysis of Swedish variety trials with winter wheat and spring barley. *Crop Sci.* **60**, 2221–2240 (2020). ](https://www.zotero.org/google-docs/?q8N38D)

[32.](https://www.zotero.org/google-docs/?q8N38D)	[Piepho, H., Möhring, J., Schulz‐Streeck, T. & Ogutu, J. O. A stage‐wise approach for the analysis of multi‐environment trials. *Biom. J.* **54**, 844–860 (2012). ](https://www.zotero.org/google-docs/?q8N38D)

[33.](https://www.zotero.org/google-docs/?q8N38D)	[Lozano-Isla, F. inti: Tools and Statistical Procedures in Plant Science. 0.6.7 https://doi.org/10.32614/CRAN.package.inti (2026). ](https://www.zotero.org/google-docs/?q8N38D)

[34.](https://www.zotero.org/google-docs/?q8N38D)	[Krueger, F. Trim Galore!: A wrapper around Cutadapt and FastQC to consistently apply adapter and quality trimming to FastQ files, with extra functionality for RRBS data. *Babraham Institute* (2015). ](https://www.zotero.org/google-docs/?q8N38D)

[35.](https://www.zotero.org/google-docs/?q8N38D)	[Li, H. & Durbin, R. Fast and accurate long-read alignment with Burrows–Wheeler transform. *Bioinformatics* **26**, 589–595 (2010). ](https://www.zotero.org/google-docs/?q8N38D)

[36.](https://www.zotero.org/google-docs/?q8N38D)	[Li, H. *et al.* The Sequence Alignment/Map format and SAMtools. *Bioinformatics* **25**, 2078–2079 (2009). ](https://www.zotero.org/google-docs/?q8N38D)

[37.](https://www.zotero.org/google-docs/?q8N38D)	[Narasimhan, V. *et al.* BCFtools/RoH: a hidden Markov model approach for detecting autozygosity from next-generation sequencing data. *Bioinformatics* **32**, 1749–1751 (2016). ](https://www.zotero.org/google-docs/?q8N38D)

[38.](https://www.zotero.org/google-docs/?q8N38D)	[Hemstrom, W. & Jones, M. snpR: User friendly population genomics for SNP data sets with categorical metadata. *Mol. Ecol. Resour.* **23**, 962–973 (2023). ](https://www.zotero.org/google-docs/?q8N38D)

[39.](https://www.zotero.org/google-docs/?q8N38D)	[Hemstrom, W., Grummer, J. A., Luikart, G. & Christie, M. R. Next-generation data filtering in the genomics era. *Nat. Rev. Genet.* **25**, 750–767 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[40.](https://www.zotero.org/google-docs/?q8N38D)	[Yin, L. *et al.* rMVP: Memory-Efficient, Visualize-Enhanced, Parallel-Accelerated GWAS Tool. 1.4.5 https://doi.org/10.32614/CRAN.package.rMVP (2019). ](https://www.zotero.org/google-docs/?q8N38D)

[41.](https://www.zotero.org/google-docs/?q8N38D)	[Liu, X., Huang, M., Fan, B., Buckler, E. S. & Zhang, Z. Iterative Usage of Fixed and Random Effect Models for Powerful and Efficient Genome-Wide Association Studies. *PLOS Genet.* **12**, e1005767 (2016). ](https://www.zotero.org/google-docs/?q8N38D)

[42.](https://www.zotero.org/google-docs/?q8N38D)	[Holland, J. B. & Piepho, H.-P. Don’t BLUP Twice. *G3 Genes Genomes Genet.* jkae250 (2024) doi:10.1093/g3journal/jkae250. ](https://www.zotero.org/google-docs/?q8N38D)

[43.](https://www.zotero.org/google-docs/?q8N38D)	[Jarvis, D. *et al.* The genome of Chenopodium quinoa. *Nature* **542**, 307–312 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[44.](https://www.zotero.org/google-docs/?q8N38D)	[Lawrence, M. *et al.* Software for Computing and Annotating Genomic Ranges. *PLOS Comput. Biol.* **9**, e1003118 (2013). ](https://www.zotero.org/google-docs/?q8N38D)

[45.](https://www.zotero.org/google-docs/?q8N38D)	[Lawrence, M., Gentleman, R. & Carey, V. rtracklayer: an R package for interfacing with genome browsers. *Bioinformatics* **25**, 1841–1842 (2009). ](https://www.zotero.org/google-docs/?q8N38D)

[46.](https://www.zotero.org/google-docs/?q8N38D)	[Montesinos-López, A. *et al.* Artificial intelligence meets genomic selection: comparing deep learning and GBLUP across diverse plant datasets. *Front. Genet.* **16**, (2025). ](https://www.zotero.org/google-docs/?q8N38D)

[47.](https://www.zotero.org/google-docs/?q8N38D)	[Endelman, J. B. Ridge Regression and Other Kernels for Genomic Selection with R Package rrBLUP. *Plant Genome* **4**, 250–255 (2011). ](https://www.zotero.org/google-docs/?q8N38D)

[48.](https://www.zotero.org/google-docs/?q8N38D)	[Meuwissen, T. H. E., Hayes, B. J. & Goddard, M. E. Prediction of Total Genetic Value Using Genome-Wide Dense Marker Maps. *Genetics* **157**, 1819–1829 (2001). ](https://www.zotero.org/google-docs/?q8N38D)

[49.](https://www.zotero.org/google-docs/?q8N38D)	[Montesinos-López, O. A. *et al.* Do feature selection methods for selecting environmental covariables enhance genomic prediction accuracy? *Front. Genet.* **14**, (2023). ](https://www.zotero.org/google-docs/?q8N38D)

[50.](https://www.zotero.org/google-docs/?q8N38D)	[Daetwyler, H. D., Calus, M. P. L., Pong-Wong, R., de los Campos, G. & Hickey, J. M. Genomic Prediction in Animals and Plants: Simulation of Data, Validation, Reporting, and Benchmarking. *Genetics* **193**, 347–365 (2013). ](https://www.zotero.org/google-docs/?q8N38D)

[51.](https://www.zotero.org/google-docs/?q8N38D)	[Chai, T. & Draxler, R. R. Root mean square error (RMSE) or mean absolute error (MAE)? – Arguments against avoiding RMSE in the literature. *Geosci. Model Dev.* **7**, 1247–1250 (2014). ](https://www.zotero.org/google-docs/?q8N38D)

[52.](https://www.zotero.org/google-docs/?q8N38D)	[Xavier, A., Xu, S., Muir, W. M. & Rainey, K. M. NAM: association studies in multiple populations. *Bioinformatics* **31**, 3862–3864 (2015). ](https://www.zotero.org/google-docs/?q8N38D)

[53.](https://www.zotero.org/google-docs/?q8N38D)	[Yin, L. *et al.* rMVP: A Memory-Efficient, Visualization-Enhanced, and Parallel-Accelerated Tool for Genome-Wide Association Study. *Genomics Proteomics Bioinformatics* **19**, 619–628 (2021). ](https://www.zotero.org/google-docs/?q8N38D)

[54.](https://www.zotero.org/google-docs/?q8N38D)	[Hernández, E. H. M. *et al.* Genetic diversity of Colombian quinoa (Chenopodium quinoa Willd.): implications for breeding programs. *Genet. Resour. Crop Evol.* https://doi.org/10.1007/s10722-022-01383-w (2022) doi:10.1007/s10722-022-01383-w. ](https://www.zotero.org/google-docs/?q8N38D)

[55.](https://www.zotero.org/google-docs/?q8N38D)	[Al-Naggar, A., El-Salam, R., Badran, A. & El-Moghazi, M. Heritability and Interrelationships for Agronomic, Physiological and Yield Traits of Quinoa (Chinopodium quinoa Willd.) under Elevated Water Stress. *Arch. Curr. Res. Int.* **10**, 1–15 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[56.](https://www.zotero.org/google-docs/?q8N38D)	[De Santis, G., D’Ambrosio, T., Rinaldi, M. & Rascio, A. Heritabilities of morphological and quality traits and interrelationships with yield in quinoa ( Chenopodium quinoa Willd.) genotypes in the Mediterranean environment. *J. Cereal Sci.* **70**, 177–185 (2016). ](https://www.zotero.org/google-docs/?q8N38D)

[57.](https://www.zotero.org/google-docs/?q8N38D)	[Böndel, K. B. & Schmid, K. J. Quinoa Diversity and Its Implications for Breeding. in *The Quinoa Genome* (ed. Schmöckel, S. M.) 107–118 (Springer International Publishing, Cham, 2021). doi:10.1007/978-3-030-65237-1\_7. ](https://www.zotero.org/google-docs/?q8N38D)

[58.](https://www.zotero.org/google-docs/?q8N38D)	[Patiranage, D. S. *et al.* Genome-wide association study in quinoa reveals selection pattern typical for crops with a short breeding history. *eLife* **11**, e66873 (2022). ](https://www.zotero.org/google-docs/?q8N38D)

[59.](https://www.zotero.org/google-docs/?q8N38D)	[Rahman, H. *et al.* Mining genomic regions associated with agronomic and biochemical traits in quinoa through GWAS. *Sci. Rep.* **14**, 9205 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[60.](https://www.zotero.org/google-docs/?q8N38D)	[Rahman, H. *et al.* Mining genomic regions associated with agronomic and biochemical traits in quinoa through GWAS. *Sci. Rep.* **14**, 9205 (2024). ](https://www.zotero.org/google-docs/?q8N38D)

[61.](https://www.zotero.org/google-docs/?q8N38D)	[Horiguchi, G. *et al.* Differential contributions of ribosomal protein genes to *Arabidopsis thaliana* leaf development. *Plant J.* **65**, 724–736 (2011). ](https://www.zotero.org/google-docs/?q8N38D)

[62.](https://www.zotero.org/google-docs/?q8N38D)	[Paniagua, C. *et al.* Dirigent proteins in plants: modulating cell wall metabolism during abiotic and biotic stress exposure. *J. Exp. Bot.* **68**, 3287–3301 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[63.](https://www.zotero.org/google-docs/?q8N38D)	[Bartrina, I., Otto, E., Strnad, M., Werner, T. & Schmülling, T. Cytokinin Regulates the Activity of Reproductive Meristems, Flower Organ Size, Ovule Formation, and Thus Seed Yield in *Arabidopsis thaliana*. *Plant Cell* **23**, 69–80 (2011). ](https://www.zotero.org/google-docs/?q8N38D)

[64.](https://www.zotero.org/google-docs/?q8N38D)	[Kieber, J. J. & Schaller, G. E. Cytokinin signaling in plant development. *Development* **145**, dev149344 (2018). ](https://www.zotero.org/google-docs/?q8N38D)

[65.](https://www.zotero.org/google-docs/?q8N38D)	[Zürcher, E. & Müller, B. Cytokinin Synthesis, Signaling, and Function—Advances and New Insights. in *International Review of Cell and Molecular Biology* vol. 324 1–38 (Elsevier, 2016). ](https://www.zotero.org/google-docs/?q8N38D)

[66.](https://www.zotero.org/google-docs/?q8N38D)	[Lorković, Z. J. Role of plant RNA-binding proteins in development, stress response and genome organization. *Trends Plant Sci.* **14**, 229–236 (2009). ](https://www.zotero.org/google-docs/?q8N38D)

[67.](https://www.zotero.org/google-docs/?q8N38D)	[Shang, X., Cao, Y. & Ma, L. Alternative Splicing in Plant Genes: A Means of Regulating the Environmental Fitness of Plants. *Int. J. Mol. Sci.* **18**, 432 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[68.](https://www.zotero.org/google-docs/?q8N38D)	[Shao, D., Gao, X. & Wei, Y. Pre-mRNA Splicing Functions in Plant Sexual Reproduction Development. *Plants* **14**, 1472 (2025). ](https://www.zotero.org/google-docs/?q8N38D)

[69.](https://www.zotero.org/google-docs/?q8N38D)	[Basu, U. *et al.* ABC Transporter-Mediated Transport of Glutathione Conjugates Enhances Seed Yield and Quality in Chickpea. *Plant Physiol.* **180**, 253–275 (2019). ](https://www.zotero.org/google-docs/?q8N38D)

[70.](https://www.zotero.org/google-docs/?q8N38D)	[Zhang, P. *et al.* CRISPR/Cas9 multiplex editing of four TaSK41 genes increases grain size and weight and reveals a TaSK41–TaSnRK1β1 module associated with carbohydrate metabolism in wheat. *Crop J.* S2214514126000310 (2026) doi:10.1016/j.cj.2026.01.008. ](https://www.zotero.org/google-docs/?q8N38D)

[71.](https://www.zotero.org/google-docs/?q8N38D)	[Zhao, J. *et al.* ABC transporter OsABCG18 controls the shootward transport of cytokinins and grain yield in rice. *J. Exp. Bot.* **70**, 6277–6291 (2019). ](https://www.zotero.org/google-docs/?q8N38D)

[72.](https://www.zotero.org/google-docs/?q8N38D)	[Crossa, J. *et al.* Genomic Selection in Plant Breeding: Methods, Models, and Perspectives. *Trends Plant Sci.* **22**, 961–975 (2017). ](https://www.zotero.org/google-docs/?q8N38D)

[73.](https://www.zotero.org/google-docs/?q8N38D)	[Visscher, P. M., Hill, W. G. & Wray, N. R. Heritability in the genomics era — concepts and misconceptions. *Nat. Rev. Genet.* **9**, 255–266 (2008). ](https://www.zotero.org/google-docs/?q8N38D)

[74.](https://www.zotero.org/google-docs/?q8N38D)	[Varshney, R. K. *et al.* Resequencing of 429 chickpea accessions from 45 countries provides insights into genome diversity, domestication and agronomic traits. *Nat. Genet.* **51**, 857–864 (2019). ](https://www.zotero.org/google-docs/?q8N38D)

[75.](https://www.zotero.org/google-docs/?q8N38D)	[McMullen, M. D. *et al.* Genetic Properties of the Maize Nested Association Mapping Population. *Science* **325**, 737–740 (2009). ](https://www.zotero.org/google-docs/?q8N38D)